package com.vinayak09.bloodbankbyvinayak.listeners;

import android.view.View;

public interface MyOnClickListener {
    void getPosition(int position);
}
